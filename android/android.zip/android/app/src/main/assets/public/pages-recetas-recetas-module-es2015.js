(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-recetas-recetas-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/recetas/recetas.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/recetas/recetas.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"success\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Recetas</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-avatar>\n        <img src=\"/assets/imagenes/Quique.png\" alt=\"avatar\" height=\"30px\" >\n      </ion-avatar>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>Nombre:</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>\n          <p>Cantidad:</p>\n        </ion-item>\n        <ion-item>\n          <p>Fecha:</p>\n        </ion-item>\n        <ion-item>\n          <p>Frecuencia:</p>\n        </ion-item>\n        <ion-item>\n          <p>Duración:</p>\n        </ion-item>\n      </ion-card-content>\n    </ion-card>\n  </ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/recetas/recetas-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/recetas/recetas-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: RecetasPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecetasPageRoutingModule", function() { return RecetasPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _recetas_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./recetas.page */ "./src/app/pages/recetas/recetas.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");





const routes = [
    {
        path: '',
        component: _recetas_page__WEBPACK_IMPORTED_MODULE_3__["RecetasPage"]
    }
];
let RecetasPageRoutingModule = class RecetasPageRoutingModule {
};
RecetasPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes),
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_4__["ComponentsModule"]
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RecetasPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/recetas/recetas.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/recetas/recetas.module.ts ***!
  \*************************************************/
/*! exports provided: RecetasPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecetasPageModule", function() { return RecetasPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _recetas_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./recetas-routing.module */ "./src/app/pages/recetas/recetas-routing.module.ts");
/* harmony import */ var _recetas_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./recetas.page */ "./src/app/pages/recetas/recetas.page.ts");







let RecetasPageModule = class RecetasPageModule {
};
RecetasPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _recetas_routing_module__WEBPACK_IMPORTED_MODULE_5__["RecetasPageRoutingModule"]
        ],
        declarations: [_recetas_page__WEBPACK_IMPORTED_MODULE_6__["RecetasPage"]]
    })
], RecetasPageModule);



/***/ }),

/***/ "./src/app/pages/recetas/recetas.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/recetas/recetas.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3JlY2V0YXMvcmVjZXRhcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/recetas/recetas.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/recetas/recetas.page.ts ***!
  \***********************************************/
/*! exports provided: RecetasPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecetasPage", function() { return RecetasPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var src_app_services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/data.service */ "./src/app/services/data.service.ts");




let RecetasPage = class RecetasPage {
    constructor(authService, dataService) {
        this.authService = authService;
        this.dataService = dataService;
        this.recetas = [];
        this.user = this.authService.getIdentity();
        this.userId = this.user.sub;
    }
    ngOnInit() {
        this.dataService.existeArchivo('registros.txt').then(res => {
            console.log("El archivo existe . ", res);
        }).catch(error => {
            console.log("El archivo no existe ", error);
        });
    }
    getRecetas() {
        this.dataService.getRecetas(this.user).subscribe(res => {
            if (res.status == 'success') {
                this.recetas = res.recetas;
            }
            else {
                this.status = 'error';
                console.log('No hay recetas');
            }
        }, error => {
            console.log(error);
        });
    }
};
RecetasPage.ctorParameters = () => [
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: src_app_services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"] }
];
RecetasPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-recetas',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./recetas.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/recetas/recetas.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./recetas.page.scss */ "./src/app/pages/recetas/recetas.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"], src_app_services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])
], RecetasPage);



/***/ })

}]);
//# sourceMappingURL=pages-recetas-recetas-module-es2015.js.map