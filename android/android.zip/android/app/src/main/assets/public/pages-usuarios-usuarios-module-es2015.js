(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-usuarios-usuarios-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/usuarios/usuarios.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/usuarios/usuarios.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header titulo=\"Usuarios\"></app-header>\r\n\r\n<ion-content>\r\n  <ion-list #listaCerrar>\r\n    <ion-item-sliding *ngFor=\"let user of usuarios\">\r\n      <ion-item>\r\n        <ion-label>\r\n          <h3>{{user.name + ' ' +user.surname}}</h3>\r\n          <p>{{user.email}}</p>\r\n        </ion-label>\r\n        <ion-label slot=\"end\" text-right>\r\n          {{user.phone}}\r\n        </ion-label>\r\n      </ion-item>\r\n      <ion-item-options side=\"start\">\r\n        <ion-item-option (click)=\"mostrarInfo(user.id)\">\r\n           <ion-icon slot=\"icon-only\" name=\"star\"></ion-icon>\r\n        </ion-item-option>\r\n      </ion-item-options>\r\n      <ion-item-options side=\"end\">\r\n        <ion-item-option color=\"tertiary\" (click)=\"mostrarDetalle(user.id)\">\r\n          <ion-icon slot=\"icon-only\" name=\"eye\"></ion-icon>\r\n        </ion-item-option>\r\n        <ion-item-option color=\"danger\" (click)=\"onDelete(user.id)\">\r\n          <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\r\n        </ion-item-option>\r\n      </ion-item-options>\r\n    </ion-item-sliding>\r\n  </ion-list>\r\n  \r\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n    <ion-fab-button>\r\n      <ion-icon name=\"add\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/usuarios/usuarios-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/usuarios/usuarios-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: UsuariosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosPageRoutingModule", function() { return UsuariosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _usuarios_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./usuarios.page */ "./src/app/pages/usuarios/usuarios.page.ts");




const routes = [
    {
        path: '',
        component: _usuarios_page__WEBPACK_IMPORTED_MODULE_3__["UsuariosPage"]
    }
];
let UsuariosPageRoutingModule = class UsuariosPageRoutingModule {
};
UsuariosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UsuariosPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/usuarios/usuarios.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/usuarios/usuarios.module.ts ***!
  \***************************************************/
/*! exports provided: UsuariosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosPageModule", function() { return UsuariosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./usuarios-routing.module */ "./src/app/pages/usuarios/usuarios-routing.module.ts");
/* harmony import */ var _usuarios_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./usuarios.page */ "./src/app/pages/usuarios/usuarios.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let UsuariosPageModule = class UsuariosPageModule {
};
UsuariosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        entryComponents: [],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_5__["UsuariosPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"],
        ],
        declarations: [_usuarios_page__WEBPACK_IMPORTED_MODULE_6__["UsuariosPage"]]
    })
], UsuariosPageModule);



/***/ }),

/***/ "./src/app/pages/usuarios/usuarios.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/usuarios/usuarios.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3VzdWFyaW9zL3VzdWFyaW9zLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/usuarios/usuarios.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/usuarios/usuarios.page.ts ***!
  \*************************************************/
/*! exports provided: UsuariosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosPage", function() { return UsuariosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/usuarios.service */ "./src/app/services/usuarios.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var src_app_components_usuario_detalle_usuario_detalle_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/usuario-detalle/usuario-detalle.component */ "./src/app/components/usuario-detalle/usuario-detalle.component.ts");
/* harmony import */ var src_app_components_info_info_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/info/info.component */ "./src/app/components/info/info.component.ts");









let UsuariosPage = class UsuariosPage {
    constructor(userService, toastController, authService, router, mdlCtrl) {
        this.userService = userService;
        this.toastController = toastController;
        this.authService = authService;
        this.router = router;
        this.mdlCtrl = mdlCtrl;
        this.usuarios = [];
        this.identity = this.authService.getIdentity();
        this.token = this.authService.getToken();
    }
    ngOnInit() {
        this.getUsers();
    }
    ionViewWillEnter() {
        this.getUsers();
    }
    getUsers() {
        this.userService.getUsers().subscribe(res => {
            if (res.status == 'success') {
                this.status = 'success';
                this.usuarios = res.users;
            }
            else {
                this.status = 'error';
            }
        }, error => {
            console.log(JSON.stringify(error));
        });
    }
    mostrarDetalle(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.mdlCtrl.create({
                component: src_app_components_usuario_detalle_usuario_detalle_component__WEBPACK_IMPORTED_MODULE_6__["UsuarioDetalleComponent"],
                componentProps: {
                    id
                }
            });
            yield modal.present();
        });
    }
    mostrarInfo(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.mdlCtrl.create({
                component: src_app_components_info_info_component__WEBPACK_IMPORTED_MODULE_7__["InfoComponent"],
                componentProps: {
                    id
                }
            });
            yield modal.present();
        });
    }
    onDelete(id) {
        this.userService.deleteUsuario(id, this.token).subscribe(res => {
            if (res.status == 'success') {
                this.presentToast('El usuario ha sido eliminado correctamente');
                this.router.navigate(['usuarios']);
            }
            else {
                this.status = 'error';
            }
        }, error => {
            this.presentToast('Ha ocurrido un problema en la eliminación del usuario: ' + JSON.stringify(error));
            console.log(JSON.stringify(error));
        });
    }
    presentToast(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message,
                duration: 3000
            });
            yield toast.present();
        });
    }
};
UsuariosPage.ctorParameters = () => [
    { type: _services_usuarios_service__WEBPACK_IMPORTED_MODULE_2__["UsuariosService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('listaCerrar', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonList"])
], UsuariosPage.prototype, "listaCerrar", void 0);
UsuariosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-usuarios',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./usuarios.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/usuarios/usuarios.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./usuarios.page.scss */ "./src/app/pages/usuarios/usuarios.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_usuarios_service__WEBPACK_IMPORTED_MODULE_2__["UsuariosService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
        _services_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
], UsuariosPage);



/***/ })

}]);
//# sourceMappingURL=pages-usuarios-usuarios-module-es2015.js.map