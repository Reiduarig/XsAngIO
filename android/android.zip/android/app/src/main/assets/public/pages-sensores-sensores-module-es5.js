function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-sensores-sensores-module"], {
  /***/
  "./node_modules/@ionic-native/db-meter/ngx/index.js":
  /*!**********************************************************!*\
    !*** ./node_modules/@ionic-native/db-meter/ngx/index.js ***!
    \**********************************************************/

  /*! exports provided: DBMeter */

  /***/
  function node_modulesIonicNativeDbMeterNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DBMeter", function () {
      return DBMeter;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var DBMeter =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(DBMeter, _super);

      function DBMeter() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      DBMeter.prototype.start = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "start", {
          "observable": true,
          "clearFunction": "stop"
        }, arguments);
      };

      DBMeter.prototype.stop = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "stop", {}, arguments);
      };

      DBMeter.prototype.isListening = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "isListening", {}, arguments);
      };

      DBMeter.prototype["delete"] = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "delete", {}, arguments);
      };

      DBMeter.pluginName = "DBMeter";
      DBMeter.plugin = "cordova-plugin-dbmeter";
      DBMeter.pluginRef = "DBMeter";
      DBMeter.repo = "https://github.com/akofman/cordova-plugin-dbmeter";
      DBMeter.platforms = ["Android", "iOS"];
      DBMeter = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], DBMeter);
      return DBMeter;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2RiLW1ldGVyL25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBMENMLDJCQUFpQjs7OztJQVM1Qyx1QkFBSztJQVNMLHNCQUFJO0lBU0osNkJBQVc7SUFTWCx3QkFBTTs7Ozs7O0lBcENLLE9BQU87UUFEbkIsVUFBVSxFQUFFO09BQ0EsT0FBTztrQkE1Q3BCO0VBNEM2QixpQkFBaUI7U0FBakMsT0FBTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luLCBQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuXG4vKipcbiAqIEBuYW1lIERCIE1ldGVyXG4gKiBAZGVzY3JpcHRpb24gVGhpcyBwbHVnaW4gZGVmaW5lcyBhIGdsb2JhbCBEQk1ldGVyIG9iamVjdCwgd2hpY2ggcGVybWl0cyB0byBnZXQgdGhlIGRlY2liZWwgdmFsdWVzIGZyb20gdGhlIG1pY3JvcGhvbmUuXG4gKiBAdXNhZ2VcbiAqIGBgYHR5cGVzY3JpcHRcbiAqIGltcG9ydCB7IERCTWV0ZXIgfSBmcm9tICdAaW9uaWMtbmF0aXZlL2RiLW1ldGVyL25neCc7XG4gKlxuICogY29uc3RydWN0b3IocHJpdmF0ZSBkYk1ldGVyOiBEQk1ldGVyKSB7IH1cbiAqXG4gKiAuLi5cbiAqXG4gKlxuICogLy8gU3RhcnQgbGlzdGVuaW5nXG4gKiBsZXQgc3Vic2NyaXB0aW9uID0gdGhpcy5kYk1ldGVyLnN0YXJ0KCkuc3Vic2NyaWJlKFxuICogICBkYXRhID0+IGNvbnNvbGUubG9nKGRhdGEpXG4gKiApO1xuICpcbiAqIC8vIENoZWNrIGlmIHdlIGFyZSBsaXN0ZW5pbmdcbiAqIHRoaXMuZGJNZXRlci5pc0xpc3RlbmluZygpLnRoZW4oXG4gKiAgIGlzTGlzdGVuaW5nID0+IGNvbnNvbGUubG9nKGlzTGlzdGVuaW5nKVxuICogKTtcbiAqXG4gKiAvLyBTdG9wIGxpc3RlbmluZ1xuICogc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gKlxuICogLy8gRGVsZXRlIERCTWV0ZXIgaW5zdGFuY2UgZnJvbSBtZW1vcnlcbiAqIHRoaXMuZGJNZXRlci5kZWxldGUoKS50aGVuKFxuICogICAoKSA9PiBjb25zb2xlLmxvZygnRGVsZXRlZCBEQiBNZXRlciBpbnN0YW5jZScpLFxuICogICBlcnJvciA9PiBjb25zb2xlLmxvZygnRXJyb3Igb2NjdXJyZWQgd2hpbGUgZGVsZXRpbmcgREIgTWV0ZXIgaW5zdGFuY2UnKVxuICogKTtcbiAqIGBgYFxuICovXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ0RCTWV0ZXInLFxuICBwbHVnaW46ICdjb3Jkb3ZhLXBsdWdpbi1kYm1ldGVyJyxcbiAgcGx1Z2luUmVmOiAnREJNZXRlcicsXG4gIHJlcG86ICdodHRwczovL2dpdGh1Yi5jb20vYWtvZm1hbi9jb3Jkb3ZhLXBsdWdpbi1kYm1ldGVyJyxcbiAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnaU9TJ11cbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgREJNZXRlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIFN0YXJ0cyBsaXN0ZW5pbmdcbiAgICogQHJldHVybnMge09ic2VydmFibGU8YW55Pn0gUmV0dXJucyBhbiBvYnNlcnZhYmxlLiBTdWJzY3JpYmUgdG8gc3RhcnQgbGlzdGVuaW5nLiBVbnN1YnNjcmliZSB0byBzdG9wIGxpc3RlbmluZy5cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlLFxuICAgIGNsZWFyRnVuY3Rpb246ICdzdG9wJ1xuICB9KVxuICBzdGFydCgpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdG9wcyBsaXN0ZW5pbmdcbiAgICogQGhpZGRlblxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBzdG9wKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIGlmIHRoZSBEQiBNZXRlciBpcyBsaXN0ZW5pbmdcbiAgICogQHJldHVybnMge1Byb21pc2U8Ym9vbGVhbj59IFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCBhIGJvb2xlYW4gdGhhdCB0ZWxscyB1cyB3aGV0aGVyIHRoZSBEQiBtZXRlciBpcyBsaXN0ZW5pbmdcbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgaXNMaXN0ZW5pbmcoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSB0aGUgREIgTWV0ZXIgaW5zdGFuY2VcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gUmV0dXJucyBhIHByb21pc2UgdGhhdCB3aWxsIHJlc29sdmUgaWYgdGhlIGluc3RhbmNlIGhhcyBiZWVuIGRlbGV0ZWQsIGFuZCByZWplY3RzIGlmIGVycm9ycyBvY2N1ci5cbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZGVsZXRlKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG4iXX0=

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sensores/sensores.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sensores/sensores.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesSensoresSensoresPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-header titulo=\"Sensores\"></app-header>\n\n<ion-content padding>\n<ion-button color=\"success\" (click)=\"start()\">Iniciar</ion-button> \n<ion-button color=\"danger\" (click)=\"stopMagnetometer()\">Parar</ion-button>    \n  \n<ion-list>\n    <h1 class=\"text-center\">Aceleración</h1>\n    <ion-item>\n        <ion-label>Alpha:</ion-label>\n        <p>{{accX}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Beta:</ion-label>\n        <p>{{accY}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Gamma:</ion-label>\n        <p>{{accZ}}</p>\n    </ion-item>\n</ion-list>\n\n<ion-list>\n    <h1 class=\"text-center\">Gyroscopio</h1>\n    <ion-item>\n        <ion-label>Heading:</ion-label>\n        <p>{{xOrient}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Pitch:</ion-label>\n        <p>{{yOrient}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Roll:</ion-label>\n        <p>{{zOrient}}</p>\n    </ion-item>\n</ion-list>\n\n<ion-list>\n    <h1 class=\"text-center\">Magnetómetro</h1>\n    <ion-item>\n        <ion-label>X:</ion-label>\n        <p>{{magX}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Y:</ion-label>\n        <p>{{magY}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Z:</ion-label>\n        <p>{{magZ}}</p>\n    </ion-item>\n    <ion-item>\n        <ion-label>Calculado:</ion-label>\n        <p>{{magCalculated}}</p>\n    </ion-item>\n</ion-list>\n<ion-list>\n    <h1 class=\"text-center\">Compass Heading</h1>\n    <ion-item>\n        <ion-label>Orientación:</ion-label>\n        <p>{{aheading}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Or.Norte Geog.:</ion-label>\n        <p>{{bheading}}</p> \n    </ion-item>\n    <ion-item>\n        <ion-label>Desviación:</ion-label>\n        <p>{{cheading}}</p> \n    </ion-item>\n</ion-list>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/sensores/sensores-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/sensores/sensores-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: SensoresPageRoutingModule */

  /***/
  function srcAppPagesSensoresSensoresRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SensoresPageRoutingModule", function () {
      return SensoresPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _sensores_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./sensores.page */
    "./src/app/pages/sensores/sensores.page.ts");

    var routes = [{
      path: '',
      component: _sensores_page__WEBPACK_IMPORTED_MODULE_3__["SensoresPage"]
    }];

    var SensoresPageRoutingModule = function SensoresPageRoutingModule() {
      _classCallCheck(this, SensoresPageRoutingModule);
    };

    SensoresPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SensoresPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/sensores/sensores.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/sensores/sensores.module.ts ***!
    \***************************************************/

  /*! exports provided: SensoresPageModule */

  /***/
  function srcAppPagesSensoresSensoresModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SensoresPageModule", function () {
      return SensoresPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _sensores_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./sensores-routing.module */
    "./src/app/pages/sensores/sensores-routing.module.ts");
    /* harmony import */


    var _sensores_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./sensores.page */
    "./src/app/pages/sensores/sensores.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");
    /* harmony import */


    var _ionic_native_db_meter_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/db-meter/ngx */
    "./node_modules/@ionic-native/db-meter/ngx/index.js");

    var SensoresPageModule = function SensoresPageModule() {
      _classCallCheck(this, SensoresPageModule);
    };

    SensoresPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _sensores_routing_module__WEBPACK_IMPORTED_MODULE_5__["SensoresPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      providers: [_ionic_native_db_meter_ngx__WEBPACK_IMPORTED_MODULE_8__["DBMeter"]],
      declarations: [_sensores_page__WEBPACK_IMPORTED_MODULE_6__["SensoresPage"]]
    })], SensoresPageModule);
    /***/
  },

  /***/
  "./src/app/pages/sensores/sensores.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/pages/sensores/sensores.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesSensoresSensoresPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NlbnNvcmVzL3NlbnNvcmVzLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/sensores/sensores.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/sensores/sensores.page.ts ***!
    \*************************************************/

  /*! exports provided: SensoresPage */

  /***/
  function srcAppPagesSensoresSensoresPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SensoresPage", function () {
      return SensoresPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_magnetometer_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/magnetometer/ngx */
    "./node_modules/@ionic-native/magnetometer/ngx/index.js");
    /* harmony import */


    var _ionic_native_gyroscope_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/gyroscope/ngx */
    "./node_modules/@ionic-native/gyroscope/ngx/index.js");
    /* harmony import */


    var _ionic_native_device_motion_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/device-motion/ngx */
    "./node_modules/@ionic-native/device-motion/ngx/index.js");
    /* harmony import */


    var _ionic_native_device_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/device-orientation/ngx */
    "./node_modules/@ionic-native/device-orientation/ngx/index.js");
    /* harmony import */


    var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/services/auth.service */
    "./src/app/services/auth.service.ts");
    /* harmony import */


    var src_app_services_data_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _ionic_native_db_meter_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/db-meter/ngx */
    "./node_modules/@ionic-native/db-meter/ngx/index.js"); // DeviceOrientationCompassHeading is an interface for compass


    var SensoresPage = /*#__PURE__*/function () {
      function SensoresPage(authService, magnetometer, gyroscope, deviceMotion, deviceOrientation, dataService, dbMeter) {
        _classCallCheck(this, SensoresPage);

        this.authService = authService;
        this.magnetometer = magnetometer;
        this.gyroscope = gyroscope;
        this.deviceMotion = deviceMotion;
        this.deviceOrientation = deviceOrientation;
        this.dataService = dataService;
        this.dbMeter = dbMeter; //opciones de los sensores

        this.Goptions = {
          frequency: 5000
        };
        this.Arraydatos = [];
        this.listaw = [];
        this.listax = [];
        this.listay = [];
        this.listaz = [];
        this.listaFecha = [];
        this.listaQuaternion = []; //decibelios

        this.listaDB = [];
        this.token = this.authService.getToken();
        this.identity = this.authService.getIdentity();
        this.idUsuario = this.identity.sub;
        this.xOrient = 0;
        this.yOrient = 0;
        this.zOrient = 0; //aceleracióm

        this.accX = 0;
        this.accY = 0;
        this.accZ = 0;
        this.magX = 0;
        this.magY = 0;
        this.magZ = 0;
        this.magCalculated = 0;
        this.aheading = 0;
        this.bheading = 0;
        this.cheading = 0;
        this.quX = 0;
        this.quY = 0;
        this.quZ = 0;
        this.degtorad = Math.PI / 180;
        this.Arraydatos = [];
        this.listaw = [];
        this.listax = [];
        this.listay = [];
        this.listaz = [];
        this.listaFecha = [];
        this.listaQuaternion = [];
        this.listaDB = [];
        this.dB = 0;
      }

      _createClass(SensoresPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "start",
        value: function start() {
          this.watchMagnetometer();
        }
      }, {
        key: "watchGyroscopio",
        value: function watchGyroscopio() {
          var _this = this;

          this.watchGyro = this.gyroscope.watch(this.Goptions).subscribe(function (orientation) {
            //console.log(orientation.x, orientation.y, orientation.z, orientation.timestamp);
            _this.xOrient = orientation.x;
            _this.yOrient = orientation.y;
            _this.zOrient = orientation.z; //si existe el usuario

            if (_this.idUsuario !== null) {
              //obtenemos la fecha actual
              _this.fecha = _this.hoyFecha();
              /* this.datos =
                           {
                             'fecha' : this.fecha,
                             'user_id': this.idUsuario,
                             'alpha' : this.accX,
                             'beta' : this.accY,
                             'gamma' : this.accZ,
                             'orientation': this.aheading,
                             'orientationNorth': this.bheading,
                             'desviacion': this.cheading,
                             'gyrox' : this.xOrient,
                             'gyroy' : this.yOrient,
                             'gyroz' : this.zOrient,
                             'magX' : this.magX,
                             'magY' : this.magY,
                             'magZ' : this.magZ,
                             'magCalculated' : this.magCalculated
                           };*/
            } else {
              console.log("No existe el usuario");
            }
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "guardarArray",
        value: function guardarArray(datos) {
          this.Arraydatos.push(datos);
        } //guardar datos en la BBDD

      }, {
        key: "enviarDatos",
        value: function enviarDatos(datos, token) {
          var _this2 = this;

          this.dataService.addData(datos, token).subscribe(function (res) {
            if (res.status = 'success') {
              _this2.status = 'success';
              console.log('Registro guardado');
            } else {
              _this2.status = 'error';
              console.log('Error en el registro');
            }
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "enviarCorreo",
        value: function enviarCorreo() {
          this.dataService.enviarCorreo(this.Arraydatos);
        }
      }, {
        key: "addZero",
        value: function addZero(i) {
          if (i < 10) {
            i = '0' + i;
          }

          return i;
        }
      }, {
        key: "hoyFecha",
        value: function hoyFecha() {
          var hoy = new Date();
          var dd = hoy.getDate();
          var mm = hoy.getMonth() + 1;
          var yyyy = hoy.getFullYear();
          var hora = hoy.getHours();
          var min = hoy.getMinutes();
          var sg = hoy.getSeconds();
          dd = this.addZero(dd);
          mm = this.addZero(mm);
          hora = this.addZero(hora);
          min = this.addZero(min);
          sg = this.addZero(sg);
          return yyyy + '-' + mm + '-' + dd + ' ' + hora + ':' + min + ':' + sg;
        } // Watch device acceleration

      }, {
        key: "watchAceleracion",
        value: function watchAceleracion() {
          var _this3 = this;

          this.subscriptionAcc = this.deviceMotion.watchAcceleration().subscribe(function (acceleration) {
            //console.log(acceleration);
            _this3.accX = acceleration.x;
            _this3.accY = acceleration.y;
            _this3.accZ = acceleration.z;
          });
        } // Stop watch

      }, {
        key: "stopAceleracion",
        value: function stopAceleracion() {
          this.subscriptionAcc.unsubscribe();
        } //gyroscopio

      }, {
        key: "stopGyroscopio",
        value: function stopGyroscopio() {
          this.watchGyro.unsubscribe();
        } // Watch the device compass heading change

      }, {
        key: "watchMagnetometer",
        value: function watchMagnetometer() {
          var _this4 = this;

          this.subscription = this.magnetometer.watchReadings().subscribe(function (data) {
            _this4.magX = data.x;
            _this4.magY = data.y;
            _this4.magZ = data.z;
            _this4.magCalculated = data.magnitude.toFixed(4); // this.listaFecha.push(this.fecha);

            _this4.startListen();

            _this4.getQuaternion(_this4.magX, _this4.magY, _this4.magZ);

            _this4.listaw.push(_this4.quW);

            _this4.listax.push(_this4.quX);

            _this4.listay.push(_this4.quY);

            _this4.listaz.push(_this4.quZ);

            _this4.listaDB.push(_this4.dB);
          });
        } // Stop watching heading change

      }, {
        key: "stopMagnetometer",
        value: function stopMagnetometer() {
          this.subscription.unsubscribe();
          this.detenerEscucha();
          this.Arraydatos.push(this.listaw);
          this.Arraydatos.push(this.listax);
          this.Arraydatos.push(this.listay);
          this.Arraydatos.push(this.listaz);
          this.Arraydatos.push(this.listaDB);
          console.log(this.Arraydatos);
          this.enviarCorreo();
        } // Watch the device compass heading change

      }, {
        key: "watchOrientacion",
        value: function watchOrientacion() {
          var _this5 = this;

          this.subscriptionOri = this.deviceOrientation.watchHeading().subscribe(function (data) {
            _this5.aheading = data.magneticHeading.toFixed(5); //console.log(data)

            _this5.bheading = data.trueHeading.toFixed(5);
            _this5.cheading = data.headingAccuracy;
          });
        } // Stop watching heading change

      }, {
        key: "stopOrientacion",
        value: function stopOrientacion() {
          this.subscriptionOri.unsubscribe();
        } //determinar el rumbo de la brújula al que se enfrenta el usuario cuando sostiene el dispositivo con la pantalla aproximadamente vertical frente a ellos.

      }, {
        key: "compassHeading",
        value: function compassHeading(alpha, beta, gamma) {
          var _x = beta ? beta * this.degtorad : 0; // beta value


          var _y = gamma ? gamma * this.degtorad : 0; // gamma value


          var _z = alpha ? alpha * this.degtorad : 0; // alpha value


          var cX = Math.cos(_x);
          var cY = Math.cos(_y);
          var cZ = Math.cos(_z);
          var sX = Math.sin(_x);
          var sY = Math.sin(_y);
          var sZ = Math.sin(_z); // Calculate Vx and Vy components

          var Vx = -cZ * sY - sZ * sX * cY;
          var Vy = -sZ * sY + cZ * sX * cY; // Calculate compass heading

          var compassHeading = Math.atan(Vx / Vy); // Convert compass heading to use whole unit circle

          if (Vy < 0) {
            compassHeading += Math.PI;
          } else if (Vx < 0) {
            compassHeading += 2 * Math.PI;
          }

          return compassHeading * (180 / Math.PI); // Compass Heading (in degrees)
        } //representa la unidad de cuaternión del dispositivo en el marco de tierra XYZ, entonces dado que el marco del cuerpo inicial está alineado con la tierra, q es como sigue.

      }, {
        key: "getQuaternion",
        value: function getQuaternion(alpha, beta, gamma) {
          var _x = beta ? beta * this.degtorad : 0; // beta value


          var _y = gamma ? gamma * this.degtorad : 0; // gamma value


          var _z = alpha ? alpha * this.degtorad : 0; // alpha value


          var cX = Math.cos(_x / 2);
          var cY = Math.cos(_y / 2);
          var cZ = Math.cos(_z / 2);
          var sX = Math.sin(_x / 2);
          var sY = Math.sin(_y / 2);
          var sZ = Math.sin(_z / 2); //
          // ZXY quaternion construction.
          //

          var w = cX * cY * cZ - sX * sY * sZ;
          var x = sX * cY * cZ - cX * sY * sZ;
          var y = cX * sY * cZ + sX * cY * sZ;
          var z = cX * cY * sZ + sX * sY * cZ;
          this.quW = w;
          this.quX = x;
          this.quY = y;
          this.quZ = z; //return [ w, x, y, z ];
        }
      }, {
        key: "startListen",
        value: function startListen() {
          var _this6 = this;

          this.subscriptionDB = this.dbMeter.start().subscribe(function (data) {
            console.log(data);
            _this6.dB = data;
          }, function (error) {
            console.log(error);
          });
          ;
        }
      }, {
        key: "comprobarEscucha",
        value: function comprobarEscucha() {
          // Check if we are listening
          this.dbMeter.isListening().then(function (isListening) {
            return console.log(isListening);
          });
        } // Stop listening

      }, {
        key: "detenerEscucha",
        value: function detenerEscucha() {
          this.subscriptionDB.unsubscribe();
        } // Delete DBMeter instance from memory

      }, {
        key: "borrarEscucha",
        value: function borrarEscucha() {
          this.dbMeter["delete"]().then(function () {
            return console.log('Deleted DB Meter instance');
          }, function (error) {
            return console.log('Error occurred while deleting DB Meter instance');
          });
        }
      }]);

      return SensoresPage;
    }();

    SensoresPage.ctorParameters = function () {
      return [{
        type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]
      }, {
        type: _ionic_native_magnetometer_ngx__WEBPACK_IMPORTED_MODULE_2__["Magnetometer"]
      }, {
        type: _ionic_native_gyroscope_ngx__WEBPACK_IMPORTED_MODULE_3__["Gyroscope"]
      }, {
        type: _ionic_native_device_motion_ngx__WEBPACK_IMPORTED_MODULE_4__["DeviceMotion"]
      }, {
        type: _ionic_native_device_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["DeviceOrientation"]
      }, {
        type: src_app_services_data_service__WEBPACK_IMPORTED_MODULE_7__["DataService"]
      }, {
        type: _ionic_native_db_meter_ngx__WEBPACK_IMPORTED_MODULE_8__["DBMeter"]
      }];
    };

    SensoresPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-sensores',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./sensores.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sensores/sensores.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./sensores.page.scss */
      "./src/app/pages/sensores/sensores.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"], _ionic_native_magnetometer_ngx__WEBPACK_IMPORTED_MODULE_2__["Magnetometer"], _ionic_native_gyroscope_ngx__WEBPACK_IMPORTED_MODULE_3__["Gyroscope"], _ionic_native_device_motion_ngx__WEBPACK_IMPORTED_MODULE_4__["DeviceMotion"], _ionic_native_device_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["DeviceOrientation"], src_app_services_data_service__WEBPACK_IMPORTED_MODULE_7__["DataService"], _ionic_native_db_meter_ngx__WEBPACK_IMPORTED_MODULE_8__["DBMeter"]])], SensoresPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-sensores-sensores-module-es5.js.map